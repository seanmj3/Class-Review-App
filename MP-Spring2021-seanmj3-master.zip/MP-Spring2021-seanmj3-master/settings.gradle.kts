rootProject.name = "Spring2021-MP"
include(":app")

pluginManagement {
    repositories {
        gradlePluginPortal()
        mavenCentral()
        maven("https://jitpack.io")
    }
}
