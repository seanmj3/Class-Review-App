package edu.illinois.cs.cs125.spring2021.mp.models;

import java.util.Objects;

/**
 * Create a public class for Course.
 */
public class Course extends Summary {
  private String description;

  /**
   * Create method for retrieving description.
   *
   * @return description
   */
  public String getDescription() {
    return description;
  }
  /**
   * Empty Constructor for serialization.
   */
  public Course() {

  }
  /**
   *Create a Summary with the provided fields.
   * @param setDescription set the description
   * @param setDepartment set the department
   * @param setNumber set the number
   * @param setSemester set the semester
   * @param setTitle set the title
   * @param setYear set the year
   */
  public Course(final String setYear,
                final String setSemester,
                final String setDepartment,
                final String setNumber,
                final String setTitle,
                final String setDescription) {
    super(setYear,
        setSemester,
        setDepartment,
        setNumber,
        setTitle);
    description = setDescription;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public boolean equals(final Object o) {
    if (!(o instanceof Course)) {
      return false;
    }
    Course course = (Course) o;
    return Objects.equals(description, course.description);
  }

  /**
   * javadoc for hash.
   * @return hash
   */

  @Override
  public int hashCode() {
    return Objects.hash(description);
  }
}

