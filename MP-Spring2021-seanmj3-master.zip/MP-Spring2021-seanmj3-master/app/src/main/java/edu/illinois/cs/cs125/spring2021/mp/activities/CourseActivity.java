package edu.illinois.cs.cs125.spring2021.mp.activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import edu.illinois.cs.cs125.spring2021.mp.R;
import edu.illinois.cs.cs125.spring2021.mp.application.CourseableApplication;
import edu.illinois.cs.cs125.spring2021.mp.databinding.ActivityCourseBinding;
import edu.illinois.cs.cs125.spring2021.mp.models.Course;
import edu.illinois.cs.cs125.spring2021.mp.models.Summary;
import edu.illinois.cs.cs125.spring2021.mp.network.Client;

/**
 * Create class for CourseActivity.
 * This class extends AppCompatActivity
 * @extends AppCompatActivity
 */
public class CourseActivity extends AppCompatActivity implements Client.CourseClientCallbacks {
  @SuppressWarnings({"unused", "RedundantSuppression"})
  private static final String TAG = CourseActivity.class.getSimpleName();
  private ActivityCourseBinding binding;

/**
 * This is for checkstyle.
 * @param savedInstanceState
 * @Override is for checkstyle
 */
  @Override
  public void onCreate(@Nullable final Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    Log.i(TAG, "CourseActivity launched");

    Intent intent = getIntent();
    ObjectMapper map = new ObjectMapper();
    try {
      binding = DataBindingUtil.setContentView(this, R.layout.activity_course);
      binding.CourseTitle.setText(getTitle());
      String course = intent.getStringExtra("COURSE");
      Summary summary = map.readValue(course, Summary.class);
      CourseableApplication application = (CourseableApplication) getApplication();
      application.getCourseClient().getCourse(summary, this);
    } catch (JsonProcessingException e) {
      e.printStackTrace();
    }

  }

  /**
   * Parameters for courseResponse.
   * @param summary
   * @param course
   */
  @Override
  public void courseResponse(final Summary summary, final Course course) {
    System.out.println(course.getDescription());
    binding.CourseDescription.setText(course.getDescription());
    binding.CourseTitle.setText(course.getTitle());
  }
}
